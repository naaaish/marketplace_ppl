<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk - Tukutuku</title>
    <style>
        /* === RESET & DASAR === */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f0f2f5;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        /* === CONTAINER UTAMA === */
        .form-container {
            width: 100%;
            max-width: 1000px;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            display: flex;
            min-height: 600px;
        }

        /* === SISI KIRI (BRANDING) === */
        .form-decoration {
            flex: 0 0 45%;
            background: linear-gradient(135deg, #102C54 50%, #43679b 100%);
            color: white;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        /* --- PENGATURAN LOGO GAMBAR --- */
        .brand-logo {
            margin-bottom: 20px;
        }

        .brand-logo img {
            /* Atur lebar logo di sini */
            width: 200px; 
            height: auto;
            border-radius: 10px; 
       
        }

        .brand-text {
            font-size: 32px;
            font-weight: 800;
            letter-spacing: -1px;
            margin-bottom: 20px;
        }

        .form-decoration p {
            font-size: 16px;
            line-height: 1.6;
            opacity: 0.9;
            max-width: 300px;
        }

        .divider {
            width: 50px;
            height: 4px;
            background-color: rgba(255,255,255,0.3);
            border-radius: 2px;
            margin-bottom: 20px;
        }

        /* === SISI KANAN (FORM) === */
        .form-content {
            flex: 1;
            padding: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .form-header {
            margin-bottom: 40px;
        }

        .form-header h2 {
            font-size: 28px;
            color: #222;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .form-header p {
            color: #666;
            font-size: 15px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #555;
            font-size: 14px;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 14px 15px;
            border: 1px solid #ced4da;
            border-radius: 8px;
            font-size: 16px;
            color: #34495e;
            background-color: #fff;
            transition: border-color 0.2s ease;
        }

        input:focus {
            outline: none;
            border-color: #102C54;
            box-shadow: 0 0 0 4px rgba(16, 44, 84, 0.15);
        }

        button[type="submit"] {
            width: 100%;
            padding: 15px;
            background-color: #102C54;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 17px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        button[type="submit"]:hover {
            background-color: #1a4a8c;
            transform: translateY(-2px);
        }

        .form-footer {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }

        .form-footer a {
            color: #102C54;
            text-decoration: none;
            font-weight: 700;
        }

        .forgot-password {
            float: right;
            font-size: 13px;
            color: #102C54;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 5px;
        }

        @media (max-width: 900px) {
            .form-container {
                flex-direction: column;
                max-width: 500px;
            }
            .form-decoration {
                display: none;
            }
            .form-content {
                padding: 40px 30px;
            }
        }
    </style>
</head>
<body>

    <div class="form-container">
        
        <div class="form-decoration">
            <div class="brand-logo">
                <img src="{{ asset('img/logo.png') }}" alt="tukutuku Logo" class="logo">
            </div>
            <p>Masuk untuk mengelola akunmu dan mulai berjualan.</p>
        </div>

        <div class="form-content">
            
            <div class="form-header">
                <h2>Selamat Datang</h2>
                <p>Silakan masukkan email dan password Anda</p>
            </div>

            <form method="POST" action="{{ route('login') }}">
                @csrf

                <div class="form-group">
                    <label for="email">Email</label>
                    <input id="email" type="email" name="email" value="{{ old('email') }}" placeholder="contoh@email.com" required autofocus>
                </div>

                <div class="form-group">
                    <label for="password">
                        Password
                        <a href="#" class="forgot-password">Lupa Password?</a>
                    </label>
                    <input id="password" type="password" name="password" placeholder="Masukkan password" required>
                </div>

                <button type="submit">Masuk Sekarang</button>

                <div class="form-footer">
                    Belum punya akun? 
                    <a href="{{ route('register') }}">Daftarkan Toko</a>
                </div>
            </form>

        </div>
    </div>

</body>
</html>