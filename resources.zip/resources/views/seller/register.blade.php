<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Daftar Penjual - Tukutuku</title>
</head>
<body>
    <h2>Daftar Sebagai Penjual</h2>

    <form method="POST" action="{{ route('seller.register.store') }}" enctype="multipart/form-data">
        @csrf
        <div>
            <label>Nama Pemilik / PIC</label><br>
            <input name="name" required>
        </div>
        <div>
            <label>Email (untuk login)</label><br>
            <input name="email" type="email" required>
        </div>
        <div>
            <label>Nama Toko</label><br>
            <input name="store_name" required>
        </div>
        <div>
            <label>Nama PIC</label><br>
            <input name="pic_name" required>
        </div>
        <div>
            <label>No. HP PIC</label><br>
            <input name="pic_phone" required>
        </div>
        <div>
            <label>Email PIC</label><br>
            <input name="pic_email" type="email" required>
        </div>
        <div>
            <label>Alamat PIC</label><br>
            <textarea name="pic_address" required></textarea>
        </div>
        <div>
            <label>Foto PIC (opsional)</label><br>
            <input type="file" name="pic_photo" accept="image/*">
        </div>
        <div>
            <label>File KTP (opsional)</label><br>
            <input type="file" name="pic_ktp_file" accept="image/*">
        </div>
        <br>
        <button type="submit">Kirim Pendaftaran</button>
    </form>

</body>
</html>
